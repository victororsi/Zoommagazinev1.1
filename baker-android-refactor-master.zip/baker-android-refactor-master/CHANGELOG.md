# Baker Android App Changelog

4.4.0:

        ▸ XWalkView 11.40.277.7 integration (Chromium version 40)
        ▸ Removal of native Android Webview
        ▸ Support for latest chromium features
        ▸ Web view stability improvements (memory-management)

4.3.0:

        ▸ Initial Release, based on refactoring bakerframework/baker-android repository
        ▸ In App Purchases and Subscriptions
        ▸ Performance optimizations
        ▸ UI / Usability optimizations (aligned with baker iOS)
